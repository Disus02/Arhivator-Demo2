package ru.sapteh;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Введите путь: ");
        String path = reader.readLine();
        Path sourcePath = Paths.get(path);
        File file = sourcePath.toFile();
        ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(file.toString() + ".zip"));


        MyVisitor myVisitor = new MyVisitor();
        ZipEntry ze;
        Files.walkFileTree(sourcePath, myVisitor);
        List<File> files = myVisitor.getFiles();
        for (File file1 : files) {
            if (file1.isDirectory()) {
                ze = new ZipEntry(file1 + "/");
                zip.putNextEntry(ze);
            } else if (file1.isFile()) {
                ze =new ZipEntry(file1.toString());
                zip.putNextEntry(ze);
                Files.copy(file1.toPath(),zip);
                zip.closeEntry();
                System.out.printf("%-35s %-5d (%d) %.0f%%\n",file1.getPath(),ze.getSize(),ze.getCompressedSize(),(100-((double)
                ze.getCompressedSize()/ze.getSize())*100));
            }
        }
        zip.close();
    }
}
